module.exports = {
  token: "6150073249:AAGIGAFHhhEV7zxKT-2zBxNN9-6ig5E0E7s",
};
