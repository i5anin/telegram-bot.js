# Clear the console screen
Clear-Host

# Change the current directory to the directory where the script is located
Set-Location $PSScriptRoot

# Run the Node.js script
node bot.js
